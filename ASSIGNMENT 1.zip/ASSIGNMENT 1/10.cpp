#include<iostream>
using namespace std;
int main()
{
int a[10];

int i;
int sum=0;
for(i=0;i<=9;i++)
{
cout<<"Enter the "<<i+1<<" Number:";
cin>>a[i];
sum=sum+a[i];
}
cout<<"Sum is: "<<sum;
}


