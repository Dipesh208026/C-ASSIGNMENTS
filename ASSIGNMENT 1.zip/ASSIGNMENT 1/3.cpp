#include<iostream>
using namespace std;
int main()
{
int x,y;
cout<<"Enter the first Number: ";
cin>>x;
cout<<"Enter the second number: ";
cin>>y;
cout<<"Sum is "<<x+y;
}
