#include<iostream>
using namespace std;
int main()
{
int x,y;
cout<<"Enter the Radius  ";
cin>>x;
cout<<"Area of the circle is  "<<x*3.14;
}
