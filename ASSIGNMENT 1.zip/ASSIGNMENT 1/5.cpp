#include<iostream>
using namespace std;
int main()
{
int x,y,z;
cout<<"Enter the length of the cuboid: ";
cin>>x;
cout<<"Enter the breadth of the cuboid: ";
cin>>y;
cout<<"Enter the height of the cuboid: ";
cin>>z;
cout<<"Volume of a cuboid is  "<<x*y*z;
}
