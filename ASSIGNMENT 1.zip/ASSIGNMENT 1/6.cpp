#include<iostream>
using namespace std;
int main()
{
int x,y,z;
cout<<"Enter the first Number: ";
cin>>x;
cout<<"Enter the Second Number: ";
cin>>y;
cout<<"Enter the Third Number: ";
cin>>z;
cout<<"Average is "<<(x+y+z)/3;
}
