#include<iostream>
using namespace std;
int main()
{
int x;
cout<<"Enter the Number: ";
cin>>x;

cout<<"Square of the number  is "<<x*x;
}
