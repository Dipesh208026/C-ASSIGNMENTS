#include<iostream>

void swap(int *x,int *y);
using namespace std;
int main()
{
int x,y;
cout<<"Enter the first Number: ";
cin>>x;
cout<<"Enter the Second Number: ";
cin>>y;
cout<<"After swapping \n";
swap(&x,&y);
cout<<"First number is:"<<x<<"\n";
cout<<"Second number is: "<<y;
}

void swap(int *x,int *y)
{
int temp;
temp=*x;
*x=*y;
*y=temp;
}
