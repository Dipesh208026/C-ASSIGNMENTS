#include<iostream>
using namespace std;
int main()
{
int x,y,z;
cout<<"Enter the first Number: ";
cin>>x;
cout<<"Enter the Second Number: ";
cin>>y;
if(x>y)
cout<<"Maximum is "<<x;
else
cout<<"Maximum is "<<y;
}
