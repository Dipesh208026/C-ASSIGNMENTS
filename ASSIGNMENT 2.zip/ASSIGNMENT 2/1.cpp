#include<iostream>
using namespace std;
void prime(int x);
main()
{
int x;
cout<<"Enter the number: ";
cin>>x;
prime(x);

}
void prime(int x)
{
int i,j;
int flag;
for(i=1;i<=x;i++)
{
    flag=0;
for(j=1;j<=i;j++)
{
    if(i%j==0)
flag++;


}

if(flag==2)
    cout<<i<<" ";
}

}







/*#include<iostream>
using namespace std;
void prime(int x);
main()
{
int x;
cout<<"Enter the number: ";
cin>>x;
prime(x);

}
void prime(int x)
{
int a[9]={2,3,4,5,6,7,8,9};
int i,j;
int flag=0;


for(j=1;j<=x;j++)
{
    if(x%j==0)
flag++;

}


if(flag==2)
cout<<"Number is PRIME";
else
cout<<"Number is NOT PRIME";



}*/













