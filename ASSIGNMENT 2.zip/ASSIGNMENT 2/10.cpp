#include<iostream>
using namespace std;
int sum(int ,int);
float sum(float,float);
main()
{
int x,y;
cout<<"Enter the First Integer Number: ";
cin>>x;
cout<<"Enter The Second Integer Number: ";
cin>>y;
cout<<"Sum of two numbers are: "<<sum(x,y)<<"\n";
float a,b;
cout<<"Enter the First float Number: ";
cin>>a;
cout<<"Enter the Second Float Number: ";
cin>>b;
cout<<"Sum is :"<<sum(a,b);
}
int sum(int x,int y)
{
return x+y;

}

float sum(float x,float y)
{
return x+y;

}
