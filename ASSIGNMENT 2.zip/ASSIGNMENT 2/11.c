#include<iostream>
using namespace std;
void pascal( int );
main()
{
int x;
cout<<"Enter the value: ";
cin>>x;
pascal(x);
}
pascal(int x)
{

int i;

int j;

for(i=1;i<=x;i++)
{

for(j=0;j<=2*x-1;j++)
{

if(j>5-i&&j<5+i)
cout<<"*";
else
cout<<" ";



}




}




}
