#include<iostream>
using namespace std;
void pascal( int,int );
int factorial(int,int);
main()
{
int a;
cout<<"Enter the no. of rows: ";
cin>>a;
int columns;
if(a%2==0)
     columns=(2*a)+1;
else
    columns=(2*a)-1;

pascal(a,columns);
}

void pascal(int a,int columns)

{

int i,j;


int y;
int x=0;



if(a%2==0)
{
 for(i=1;i<=a;i++)
{
    y=0;
for(j=1;j<=columns;j++)
{

if(i%2!=0&&j%2==0&&j<=a+(i-1)&&j>=a-(i-1)||i%2==0&&j%2!=0&&j<=a+i&&j>=a-i)
    {
        int print=factorial(x,y);
        printf("%d",print);
        y++;


    }

else
printf(" ");

}
printf("\n");
x++;
}
}
else if(a%2!=0)
   {
       for(i=1;i<=a;i++)
{
    y=0;
for(j=1;j<=columns;j++)
{

if(i%2==0&&j%2==0&&j<=a+(i-1)&&j>=a-(i-1)||i%2!=0&&j%2!=0&&j<=a+i&&j>=a-i)
{
    int print=factorial(x,y);
        printf("%d",print);
        y++;
}

else
printf(" ");

}
printf("\n");
x++;
}


}


}




int factorial(int n,int r)

{
    int i;
    int a=1;
 for(i=n;i>=1;i--)
 {
     a=a*i;
 }
    // factorial of n is stored in a;
    int b=1;
     for(i=r;i>=1;i--)
 {
     b=b*i;
 }
 // factorial of r is stored in b;

 int z=n-r;
 int c=1;
    for(i=z;i>=1;i--)
 {
     c=c*i;
 }
 // factorial of z is stored in c;
if(r==0)
   b==1;
 int d=c*b;
 int factfinal=a/d;
return factfinal;


}



















