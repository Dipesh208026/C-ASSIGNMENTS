#include<iostream>
void check(int x);
using namespace std;
main()
{
    int x;
  cout<<"Enter the Number: ";
  cin>>x;

    check(x);


}

void check(int x)
{
int   k=x;
int r,q,i,j;
    //first we have to check the no. of digits...
int y=0;
    while(x!=0)
    {
        q=x/10;
        r=x%10;
        x=q;
        y++;


    }
    cout<<"Number of digits are: "<<y;
    cout<<endl;

    int a[100];
for(i=0;i<=y-1;i++)
{
    r=k%10;
    a[i]=r;
    q=k/10;
    k=q;


}
    for(i=0;i<y-1;i++)
    {
        for(j=i+1;j<=y-1;j++)
        {
            if(a[i]>=a[j])
            {int temp;
            temp=a[i];
            a[i]=a[j];
            a[j]=temp;}
        }

    }

    cout<<"Largest value is: "<<a[y-1];

/*for(i=0;i<=y-1;i++)
{
    cout<<a[i]<<" ";
}*/

}
