#include<iostream>
void power(int x,int y);
using namespace std;
main()
{
int x,y;
cout<<"Enter the number: ";
cin>>x;
cout<<"Enter the power: ";
cin>>y;
power(x,y);

}

void power(int x,int y)
{
int z=1;
while(y!=0)
{
z=z*x;
y--;

}
cout<<"Answer is: "<<z;
}
