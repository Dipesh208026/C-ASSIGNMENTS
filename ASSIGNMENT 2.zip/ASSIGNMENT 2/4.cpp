#include<iostream>
void swap(int &x,int &y);
using namespace std;
main()
{
int x,y;
cout<<"Enter the first number: ";
cin>>x;
cout<<"Enter the second number: ";
cin>>y;
cout<<"Before swapping: ";
cout<<endl;
cout<<"First Number is: "<<x<<"\n";
cout<<"Second Number is: "<<y<<"\n";
cout<<"After swapping: ";
cout<<endl;
swap(x,y);
cout<<"First Number is: "<<x<<"\n";
cout<<"Second Number is: "<<y<<"\n";

}

void swap(int &x,int &y)
{
int temp;
temp=x;
x=y;
y=temp;

}


