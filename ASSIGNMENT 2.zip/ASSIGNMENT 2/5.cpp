#include<iostream>
using namespace std;
void fibbo(int);
main()
{
int x;
cout<<"Enter the number: ";
cin>>x;
fibbo(x);

}
void fibbo(int x)
{

int a=0;
int b=1;
int i,c;
int flag=0;
for(i=3;i<=x;i++)
{
c=a+b;
a=b;
b=c;
if(c==x)
flag++;
}


if(flag==1||x==0||x==1)
cout<<"Yes! this is in fibonnaci series ";
else
cout<<"No! this is not in fibonacci series: ";
}
