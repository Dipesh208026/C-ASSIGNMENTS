#include<iostream>
int add(int ,int ,int=0);
using namespace std;
int main()
{
int x,y,z;
cout<<"Enter the two numbers: ";
cin>>x>>y;
cout<<"Sum is "<<add(x,y);
cout<<endl;
cout<<"Enter the Three numbers: ";
cin>>x>>y>>z;
cout<<"Sum is "<<add(x,y,z);
}

int add(int x,int y,int z)
{
return x+y+z;

}


