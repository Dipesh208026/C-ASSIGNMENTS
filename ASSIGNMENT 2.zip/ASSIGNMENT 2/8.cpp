#include<iostream>
using namespace std;
float area(int);
int area(int,int);
float area(float,float); // signature i.e function name and arguments  will not same;
main()
{
int r;
int l,b;
float base,h;
cout<<"Enter the radius: ";
cin>>r;
cout<<"Area of the circle is: "<<area(r)<<"\n";
cout<<"Enter the length and breadth of rectangle1: ";
cin>>l>>b;
cout<<"Area of rectangle is: "<<area(l,b)<<"\n";
cout<<"Enter the base and height of the Triangle: ";
cin>>base>>h;
cout<<"Area of Trianlge is: "<<area(base,h);
}

float area(int r)
{
return 3.14*r*r;

}

int area(int l,int b)
{
return l*b;
}

float area(float base,float h)
{
return 0.5*base*h;
}
