#include<iostream>
using namespace std;
int max(int ,int);
float max(float,float);
main()
{
int x,y;
cout<<"Enter the First Integer Number: ";
cin>>x;
cout<<"Enter The Second Integer Number: ";
cin>>y;
cout<<"Maximum of two numbers are: "<<max(x,y)<<"\n";
float a,b;
cout<<"Enter the First real Number: ";
cin>>a;
cout<<"Maximum of Second real Number: ";
cin>>b;
cout<<"Maximum is :"<<max(a,b);
}
int max(int x,int y)
{
if(x>y)
return x;
else
return y;

}

float max(float x,float y)
{
if(x>y)
return x;
else
return y;

}
