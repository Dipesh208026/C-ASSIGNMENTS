#include<iostream>
using namespace std;
int factorial(int,int);
main()
{
int n,r;
cout<<"Enter the value of n: ";
cin>>n;
cout<<"Enter the value of r: ";
cin>>r;
int d=factorial(n,r);
cout<<d;

}
int factorial(int n,int r)

{
    int i;
    int a=1;
 for(i=n;i>=1;i--)
 {
     a=a*i;
 }
    // factorial of n is stored in a;
    int b=1;
     for(i=r;i>=1;i--)
 {
     b=b*i;
 }
 // factorial of r is stored in b;

 int z=n-r;
 int c=1;
    for(i=z;i>=1;i--)
 {
     c=c*i;
 }


 // factorial of z is stored in c;
 if(r==0)
    b==1;
 int d=c*b;
 int factfinal=a/d;
return(factfinal);


}
