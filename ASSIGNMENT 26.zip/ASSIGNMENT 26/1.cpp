#include<iostream>
using namespace std;
class complex1
{
    private:
    int a;
    int b;
    public:
        void setdata(int x,int y)
        {
           a=x;
           b=y;
        }

  void showdata()
        {
          cout<<a<<"+i"<<b;
        }
  complex1 add(complex1 c)
        {
           complex1 temp;
           temp.a=c.a+a; // ADD FUNCTION ME JO A AUR B HONGE VO C1 KE HONGE KYUNKI C1 NE ADD FUNCTION KO CALL KIYA HAI
           temp.b=c.b+b;
           return temp;

        }


};

main()
{
  complex1 c1,c2,c3; // c2 and c2 are the objects...

   c1.setdata(3,4); // c1 calls the member function of complex class;
    c2.setdata(5,3);

   c3= c1.add(c2); //c2 is and argument of complex type
    c3.showdata();

}
