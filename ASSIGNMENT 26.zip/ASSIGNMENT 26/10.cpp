#include<iostream>
using namespace std;
class staticcount
{

static int k;
public:
void increament()
{

k++;
}
void display()
{
cout<<"Value of k after 3 increament is: "<<k;

}

};

int staticcount::k; // define the static member to give some memory.

main()
{

staticcount c1;
c1.increament();
c1.increament();
c1.increament();
c1.display();
}
