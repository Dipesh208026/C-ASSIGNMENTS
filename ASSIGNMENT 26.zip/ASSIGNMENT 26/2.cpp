#include<iostream>
using namespace std;
class Time
{
    private:
    int h;
    int m;
    int s;
    public:
        void setTime(int x,int y,int z)
        {
           h=x;
        m=y;
        s=z;
        }

  void showTime()
        {
          cout<< h <<":" << m <<":" << s;
        }
  Time add( Time c)
        {

        }

        void normalize() // means show time in correct way i.e 7:65 = 8:05
        {

  if(m>60)
  {
   m=m-60;
   h=h+1;
   }


        }


};

main()
{

Time c1,c2,c3;
int x,y,z;
cout<<"Enter the time: "<<endl;
cout<<endl;
cout<<"Enter the hours: "<<endl;
cin>>x;
cout<<"Enter the minutes: "<<endl;
cin>>y;
cout<<"Enter the seconds: "<<endl;
cin>>z;

c1.setTime(x,y,z);
c1.normalize();
c1.showTime();



}










