#include<iostream>
using namespace std;
class cube
{
// their are two types of constructor 1 default and 2nd one is parameterized constructor
 private:

 int a;
public:
     cube()
 {
     cout<<"Default constructor is called: "<<endl;
    a=3;
 }
     cube(int b)
 {
    cout<<"Parametrized constructor is called: "<<endl;
    a=b;

 }
 void volume()
 {
cout<<"volume of cube is: "<<a*a*a;
cout<<endl;
 }


};

main()
{
cube c1;
c1.volume();
cube c2(2);
c2.volume();
}
