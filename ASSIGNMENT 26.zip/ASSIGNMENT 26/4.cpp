#include<iostream>
using namespace std;
class counter
{

private:
    int count1;

public:

counter()
{
     cout<<"Before  function is called: "<<endl;
    count1=0;


       cout<<endl;

}

void display()
{

    cout<<"Value is: "<<count1;
    cout<<endl;
}

void count2()
{

      count1++;
        cout<<"After function is called: "<<endl;
    cout<<endl;
}


};

main()
{

   counter c1;
      c1.display();
   c1.count2();
   c1.display();



}
