#include<iostream>
using namespace std;

class date
{

private:
int day;
int month;
int year;

public:

date()
{
day= 18;
month=07;
year=2000;


}
void display()
{
cout<<"DATE IS: "<<day<<":"<<month<<":"<<year;

}


};
main()
{

date c1;
c1.display();



}
