#include<iostream>
using namespace std;

class student
{

private:
string name;
int age;
int class1;
int roll_no;

public:

student()
{
name="Dipesh";
age=22;
class1=15;
roll_no=54;


}
void display()
{
cout<<"Name of the student is: "<<name<<endl;
cout<<"Age of the student is: "<<age<<endl;
cout<<"Class of the student: "<<class1<<endl;
cout<<"Roll no of the student: "<<roll_no<<endl;

}


};
main()
{

student c1;
c1.display();



}
