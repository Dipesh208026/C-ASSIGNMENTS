#include<iostream>
using namespace std;

class volume
{

private:
int length;
int breadth;
int height;

public:

volume (int a,int b,int c)
{
length=a;
breadth=b;
height=c;


}
void display()
{
cout<<"Volume of a rectangle: "<<length*breadth*height;
cout<<endl;

}


};
main()
{

volume c1(20,20,30);
c1.display();



}
