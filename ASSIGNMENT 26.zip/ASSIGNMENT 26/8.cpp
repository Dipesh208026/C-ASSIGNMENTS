#include<iostream>
using namespace std;

class bank
{

private:
int principal;
int rate ;
int year;

public:

 bank(int a,int b,int c)
{
principal=a;
rate=b;
year=c;


}
void display()
{

float s;
s=(float)principal*rate*year;
s=s*0.01;
cout<<"Simple Interest is: "<<s;
cout<<endl;

}





};
main()
{

bank c1(10000,2,2);
c1.display();



}
