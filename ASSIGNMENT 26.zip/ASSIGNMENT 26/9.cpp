#include<iostream>
using namespace std;

class bill
{

private:
string name;
int unit;
public:


void get()
{

cout<<"Enter the name: ";
cin>>name;
cout<<"Enter the units consumed :";
cin>>unit;

}
void calculate()
{

if(unit<=100)
{cout<<"NAME OF CUSTOMER: "<<name<<endl;
 cout<<"Total bill: "<<1.20*unit<<endl;
 cout<<"THANK YOU";
}

else if(unit<=200&&unit>100)
{cout<<"NAME OF CUSTOMER: "<<name<<endl;
 cout<<"Total bill: "<<2*unit<<endl;
 cout<<"THANK YOU";
}

else if(unit>200)
{cout<<"NAME OF CUSTOMER: "<<name<<endl;
 cout<<"Total bill: "<<3*unit<<endl;
 cout<<"THANK YOU";
}

}




};
main()
{

bill c1;
c1.get();
c1.calculate();


}
