#include<iostream>
using namespace std;
class matrix
{
  private :

  int a[3][3];

  public:
     friend void operator>>(istream &input,matrix &p);// no requirement for copy constructor as we pass reference
friend int operator<<(ostream &output,matrix &p);

matrix operator+(matrix b)
{

cout<<"+ operator called"<<endl;
matrix temp;

  int i,j;
  for(i=0;i<=2;i++)
  {

    for(j=0;j<=2;j++)
    {

       temp.a[i][j]= a[i][j]+b.a[i][j];

       // for multiplication

         //   temp.a[i][j]= (a[i][0]*b.a[0][j]) + (a[i][1]*b.a[1][j])  + (a[i][2]*b.a[2][j]);
    }



  }
  return temp;
}

void operator=(matrix f)
{
    cout<<"= operator called"<<endl;
   int i,j;
   for(i=0;i<=2;i++)
   {
       for(j=0;j<=2;j++)
       {
           a[i][j]=f.a[i][j];

       }

   }
}

};

void operator>>(istream &input,matrix &p)
{
    int i,j;
   for(i=0;i<=2;i++)
   {
       for(j=0;j<=2;j++)
       {
           input>>p.a[i][j];

       }

   }

}

int operator<<(ostream &output,matrix &p)
{

    int i,j;
   for(i=0;i<=2;i++)
   {
       for(j=0;j<=2;j++)
       {
           output<<p.a[i][j]<<"  ";

       }
       output<<endl;

   }
}

main()
{

matrix m1,m2,m3;
cout<<"Enter matrix Element (3x3): ";
cin>>m1;
cout<<endl;
cout<<"Enter matrix Element (3x3): ";
cin>>m2;
cout<<endl;
cout<<"First Matrix: "<<endl;
cout<<m1;
cout<<"Second Matrix: "<<endl;
cout<<m2;
cout<<endl;
cout<<"Addition of Matrix: ";
cout<<endl;
m3=m1+m2;
cout<<m3;
}

