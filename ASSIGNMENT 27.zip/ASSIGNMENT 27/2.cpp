#include<iostream>
using namespace std;
class complex1
{
private:
    int a,b,c,d;
public:

   complex1 operator+()
   {

    complex1 temp;
       temp.a=a;
       return temp;

   }
   complex1 operator-()
   {

    complex1 temp;
       temp.a=-a;
       return temp;

   }
    void get()
    {
        cout<<"Enter the Number: "<<endl;
        cin>>a;


    }

    void display()
    {

        cout<<"Final value of a is: "<<a<<endl;
    }





};
main()
{

    complex1 c1,c2,c3;
    c1.get();
    c2.get();
   c3= +c1;
   c3.display();
   c3=-c2;
   c3.display();


}
