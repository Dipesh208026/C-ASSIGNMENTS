#include<iostream>
using namespace std;
class complex1
{
private:
    int a,b,c,d;
public:

friend complex1 operator+(complex1 c,complex1);


    void get()
    {
        cout<<"Enter the Real Number: "<<endl;
        cin>>a;
        cout<<"Enter the Imaginary Number: "<<endl;
        cin>>b;


    }

    void display()
    {

        cout<<"Sum is: "<<a<<" +"<<b<<"i"<<endl;

    }





};

complex1 operator+(complex1 c,complex1 y)
   {

    complex1 temp;
       temp.a=c.a+y.a;
       temp.b=c.b+y.b;
       return temp;

   }

main()
{

    complex1 c1,c2,c3;
    c1.get();
    c2.get();
   c3= c2+c1;
   c3.display();



}
