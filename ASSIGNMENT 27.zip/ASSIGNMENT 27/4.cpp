#include<iostream>
using namespace std;
class time
{

  private:
      int hours ;
      int minutes;
      int seconds;

  public:

friend void operator<<(ostream &os,time &t1);
friend void operator>>(istream &os,time &t);

int operator==(time t1)
    {
        int tot=hours*3600+minutes*60+seconds;
        int tot1=t1.hours*3600+t1.minutes*60+t1.seconds;

        if(tot==tot1)
    return 1;
    else
        return 0;
    }
};


 void operator>>(istream &os,time &t)
{
    cout<<"Enter Hours: ";
   os>>t.hours;
   cout<<"Enter Minutes: ";
   os>>t.minutes;
   cout<<"Enter Seconds: ";
   os>>t.seconds;
}


void operator<<(ostream &os,time &t1)
{
    cout<<"Hours : "<<t1.hours<<endl;
    cout<<"Minutes : "<<t1.minutes<<endl;
    cout<<"Seconds : "<<t1.seconds<<endl;


}

main()
{
time t1,t2;
cout<<"Enter First time: "<<endl;
cout<<"------------------------"<<endl;
cin>>t1;
cout<<"First time"<<endl;
cout<<t1;
cout<<"Enter Second time: "<<endl;
cout<<"------------------------"<<endl;
cin>>t2;
cout<<t2;
if(t1==t2)
cout<<"Time is Same"<<endl;
else
    cout<<"Time is not Same"<<endl;




}
