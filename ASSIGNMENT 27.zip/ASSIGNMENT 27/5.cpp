#include<iostream>
using namespace std;
class numbers
{

private:
    int x,y,z;
public:



void get()
{
 cout<<"Enter the number: ";
 cin>>x;
}
void show()
{

    cout<<x;
}
void operator -()
{
    x=-x;
}

};

main()
{
   numbers x;

x.get();
-x;
x.show();




}
