#include<iostream>
#include <bits/stdc++.h>
using namespace std;
class str
{

private:
    char a[100];
    char b[100];


public:
    void input()
    {
        gets(a);
    }
    void show()
    {
        cout<<a;

    }

    void operator+(str second)

    {
        strcpy(b,a);
      strcat(a,second.a);
 cout<<a;
    }

int operator==(str y)
{
    int result;
    result=strcmp(b,y.a);
    return result;
}

};


main()
{
    str c1,c2;

    cout<<"Enter String : ";
    c1.input();
    cout<<"Enter String : ";
    c2.input();

cout<<"-----------------------"<<endl;
cout<<"First String is : ";
 c1.show();
 cout<<endl;
 cout<<"Second String is : ";
 c2.show();
 cout<<endl;
cout<<"Concatenated String is : ";
c1+c2;
cout<<endl;
int result;
result= c1==c2;
if(result==0)
    cout<<"Strings are same";
else
    cout<<"Strings are not same";



}
