#include<iostream>
using namespace std;

class fraction
{
private:
    int n,d;
public:

    friend void operator<<(ostream &os,fraction &f1); // reference issiliye pass kiya kyunki copy constructor na banana pade
  friend void operator>>(istream &os,fraction &f2);




fraction operator++(int dummy)
{

fraction temp;
cout<<"++ post operator called"<<endl;
 temp.n=n++;
 temp.d=d++;
 return temp;

}

fraction operator++()
{
    fraction temp;
cout<<"++ pre operator called"<<endl;
      temp.n=++n;
      temp.d=++d;
return temp;

}
void  operator=(fraction temp)
{
    cout<<"assignment operator called"<<endl;
    n=temp.n;
    d=temp.d;

}

};
void  operator<<(ostream &os,fraction &f1)
{
    os<<f1.n<<"/"<<f1.d<<endl;


}
  void operator>>(istream &os,fraction &f2)
  {

  cout<<"Numerator: ";
  os>>f2.n;
  cout<<endl;
  cout<<"Denominator: ";
  os>>f2.d;

  }




main()

{

fraction f1,f2;
cout<<"Enter 1st fraction value: "<<endl;
cin>>f1;
cout<<"f1++ : ";
f1++;
cout<<f1; // printing the fraction value
cout<<"++f1 : ";
++f1;
cout<<f1; // printing the fraction value
cout<<"Enter 2nd fracation value: "<<endl;
cin>>f2;
cout<<"f2 = ++f1"<<endl;
f2=++f1; // first ++operator then assign value to f2..
cout<<"f1 : ";
cout<<f1; // printing the fraction value
cout<<"f2 : ";
cout<<f2; // printing the fraction value
cout<<"f2 = f1++"<<endl;
f2=f1++; // first assignment operator and the ++operator
cout<<"f1 : ";
cout<<f1;
cout<<"f2 : ";
cout<<f2;

}
