#include<iostream>
using namespace std;
class matrix
{

private:
    int a[3][3];
public:

   friend void operator>>(istream &input,matrix &p);// no requirement for copy constructor as we pass reference
friend int operator<<(ostream &output,matrix &p);

void operator-()
{

   int i,j;
   for(i=0;i<=2;i++)
   {
       for(j=0;j<=2;j++)
       {

          a[i][j]=-a[i][j];

       }

   }
}




};
void operator>>(istream &input,matrix &p)
{
    int i,j;
   for(i=0;i<=2;i++)
   {
       for(j=0;j<=2;j++)
       {
           input>>p.a[i][j];

       }

   }

}


int operator<<(ostream &output,matrix &p)
{

    int i,j;
   for(i=0;i<=2;i++)
   {
       for(j=0;j<=2;j++)
       {
           output<<p.a[i][j]<<"  ";

       }
       output<<endl;

   }




}
main()
{
    // we overload << and >> for storing and printing the matrix values...
    cout<<"Enter matrix element (3x3): "<<endl;
    matrix m;
cin>>m;
cout<<"Matrix is: "<<endl;
cout<<m;
cout<<endl;
// we overload - for negate the numbers....

-m;
cout<<"After putting negative sign on each element...."<<endl;
cout<<m;




}
