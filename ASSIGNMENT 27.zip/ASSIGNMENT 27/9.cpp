#include<iostream>
#include <bits/stdc++.h>
using namespace std;
class mystring
{
private:
    char a[100];

public:


void input()
{
gets(a);
}

void show()
{
    cout<<a;

}

void operator!( )
{

  int i;
  for(i=0;i<strlen(a);i++)
  {
      if(a[i]<=90&&a[i]>=65)
         a[i]=a[i]+32;

      else if(a[i]<=122&&a[i]>=97)
        a[i]=a[i]-32;

  }


}

};




main()
{
    mystring a;
    // overloading  >> for taking input from user

    cout<<"Enter the string"<<endl;
    a.input();
    // overloading the operator ! for reverse the case of alphabet...
!a;
a.show();

}
