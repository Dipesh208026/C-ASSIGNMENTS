#include<iostream>
using namespace std;
class complex
{

private:

int real;
int imaginary;
public:

complex ()
{

}

complex (int a,int b)
{
    real=a;
    imaginary=b;
}


// using friend operator
friend ostream& operator<<(ostream &output ,complex &a);
friend void operator>>(istream &output ,complex &b);





};
void operator>>(istream &input ,complex &b)
{

cout<<"Enter the real part: ";
cin>>b.real;
cout<<"Enter the imaginary part: ";
cin>>b.imaginary;

}

ostream& operator<<(ostream &output ,complex &a)
{
output<<a.real<<"+"<<a.imaginary<<"i"<<endl;
return output;
}



main()
{

complex c1(1,2);
complex c2(3,4);
cin>>c1;
cout<<c1<<c2;





}
