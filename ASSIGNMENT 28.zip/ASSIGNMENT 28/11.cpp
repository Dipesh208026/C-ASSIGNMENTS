s#include<iostream>
using namespace std;
class Marks
{


int m;
public:

Marks() // Default constructor
{

}

Marks (int a) // parameterized constructor
{
m =a;
}


void print()
{

cout<<m<<endl;
}
Marks* operator->()
{
    return this;
}



};


main()
{


Marks s1(50);
s1.print();
s1->print();



}
