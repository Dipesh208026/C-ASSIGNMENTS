#include<iostream>
using namespace std;
class complex
{

private:
    // instance variable
int real;
int imaginary;
int size;


public:
complex() // default constructor called
{


}

complex(int a,int b) // parameterized constructor called
{
   real=a;
   imaginary=b;
}



void setData(int real,int imaginary)
{
// jis object ne setdata function call kiya hai
//uske real aur imaginary me 4,5 assign karwana hai
this->real=real; // this likhne se vo wala real mana jayega jo object ke ander hai
this->imaginary=imaginary;




}
void showData()
{

cout<<real<<"+"<<imaginary<<"i"<<endl;
}




};

main()
{
complex c1(3,4);
c1.setData(4,5);
c1.showData();





}
