#include<iostream>
using namespace std;
class subscript
{

int index;
int a[100];
int size=100;

public:
void setdata(int c,int b)
{
if(b>size)
{
cout<<"Index is Out of Bound";
exit(0);
}
a[b]=c;


}
void show(int index)
{
if(index>size)
{
cout<<"Index is Out of Bound";
exit(0);
}
cout<<a[index];

}

};

main()
{
subscript c;

c.setdata(3,10);
c.show(10);




}

