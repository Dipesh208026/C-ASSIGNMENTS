#include<iostream>
using namespace std;
class complex1
{

int real;
int imaginary;
public:
complex1()
{

}
complex1(int a,int b)
{
real=a;
imaginary=b;


}

void show()
{

cout<<"REAL ="<<real<<" IMAGINARY= "<<imaginary<<endl;
}

void operator=(complex1 b)
{
    real=b.imaginary;
    imaginary=b.real;
}




};
main()
{
complex1 c1(5,10);
complex1 c2(6,11);
c1.show();
c2=c1; // with interchanging values
c2.show();


}
