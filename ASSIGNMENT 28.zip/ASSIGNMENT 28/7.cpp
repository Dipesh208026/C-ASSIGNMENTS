#include<iostream>
using namespace std;
class integer
{
int a;

public:

integer(int c)
{
a=c;
}

int operator!()
{
if(!a)
return 1;
else
return 0;

}


};

main()
{
integer c1(1);
integer c2(0);
if(!c1)
cout<<"Value is true";
else
cout<<"Value is fasle";
cout<<endl;
if(!c2)
cout<<"Value is true";
else
    cout<<"Value is False";




}
