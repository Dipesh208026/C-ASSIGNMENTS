#include<iostream>
using namespace std;

class cordinate
{
    int x,y,z;
public:

    //making default comstructor
    cordinate()
    {

    }
    // making an parameterized constructor
    cordinate (int a,int b,int c)
    {
        x=a;
        y=b;
        z=c;
    }

    //making copy constructor
    cordinate(const cordinate &k) // whenever we make copy constructor
                                 // then we should pass the address i.e '&'
    {
        x=k.x;
        y=k.y;
        z=k.z;
    }

    void setdata()
    {
     cin>>x>>y>>z;

    }
    void display()
    {
        cout<<"x= "<<x<<" y= "<<y <<" z= "<<z <<endl;
    }

    // member function overloading

     cordinate operator,(cordinate c2)
     {

       cordinate temp;
       temp.x=c2.z;
       temp.y=c2.y;
       temp.z=c2.x;

       return temp;

     }

};

main()
{
cordinate c4;
cordinate c1(1,2,3);
cordinate c2(4,5,6);
cordinate c3(3,4,5);
c4=(c1,c2,c3); // first ,operator called and then default constructor
            // and then copy constructor;
c4.display();

}
