#include<iostream>
using namespace std;

class Complex
{
int x;
public:

Complex()
{
cout<<"Default Constructor is used "<<endl;

}

Complex( int y)
{
    cout<<"Parameterized constructor is used" <<endl;
x=y;
}

void display()
{
    cout<<x<<endl;
}




};

main()
{
Complex c1;
int x=5;
c1=(Complex)x;
c1.display();
return 0;


}
