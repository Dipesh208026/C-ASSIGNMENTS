#include<iostream>
using namespace std;

class Rupee
{
float r;
public:

Rupee() // Default constructor
{}

Rupee(float x) // parameterized constructor
{
r=x;

}

float getr()
{
return r;
}

void setr(int i)
{
r=i;
}
void display()
{

    cout<<"Rupee is "<<r<<endl;
}

};

class Dollar
{
float d;
public:

Dollar ()
{

}

Dollar(Rupee r1) // parameterized constructor
{

 d=r1.getr()/100;


}

operator Rupee()
{
cout<<"Dollar to Rupee"<<endl;
Rupee temp;
int t=d*82;
temp.setr(t);
return temp;

}

void display()
{

    cout<<"Dollar is "<<d<<endl;
}


};

main()
{
Rupee r=20;
Dollar  d=r; // Rupee to Dollar conversion

d.display();
r.display();

r=d ;// Dollar to Rupee Conversion
d.display();
r.display();


}
