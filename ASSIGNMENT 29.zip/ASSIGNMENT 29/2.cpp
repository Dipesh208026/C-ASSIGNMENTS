#include<iostream>
using namespace std;

class Complex
{
int x,y;
public:

Complex()
{
cout<<"Default Constructor is used "<<endl;

}

Complex( int y)
{
    cout<<"Parameterized constructor is used" <<endl;
x=y;
}

  operator int() // typecasting
  {

  return x;

  }

void display()
{
    cout<<x<<endl;
}

void setData(int j,int k)
{

x=j;
y=k;

}



};

main()
{
Complex c1;
c1.setData(3,4);
int x;
x=c1;
cout<<x<<endl;
return 0;


}
