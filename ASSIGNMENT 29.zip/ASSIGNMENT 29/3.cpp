#include<iostream>
using namespace std;

class Product
{
int x,y;

public:

Product()
{
cout<<"Default constructor called "<<endl;

}

int getx()
{
    return x;
}
int gety()
{
    return y;
}


void setData(int j,int k)
{
x=j;
y=k;

}

void display()
{
cout<<"x= "<<x<<" y= "<<y<<endl;

}


};
class Item
{


int x,y;
public:

Item()
{
cout<<"Default constructor Called "<<endl;

}


Item( Product p)  // parameterized constructor
{
x=p.getx();
y=p.gety();

}

void display()
{
cout<<"x= "<<x<<" y= "<<y<<endl;

}






};



main()
{

Item i1;
Product p1;
p1.setData(3,4);
i1=p1; // type casting from one class to another
i1.display();
return 0;




}







