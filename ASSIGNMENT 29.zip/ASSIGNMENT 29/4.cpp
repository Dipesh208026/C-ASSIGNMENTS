#include<iostream>
using namespace std;
class Product
{
int l,m;

public:

Product()
{
cout<<"Default constructor called "<<endl;

}




void setData(int j,int k)
{
l=j;
m=k;

}

void display()
{
cout<<"x= "<<l<<" y= "<<m<<endl;

}

operator Item()
{
  Item i;
  i.setx(l);
  i.sety(m);

return i;
}

};

class Item
{


int x,y;
public:

Item()
{
cout<<"Default constructor Called "<<endl;

}

void setx(int m)
{
    x=m;
}
void sety(int n)
{
    y=n;
}
//Item( Product p)  // parameterized constructor
//{
//x=p.getx();
//y=p.gety();

//}




void display()
{
cout<<"x= "<<x<<" y= "<<y<<endl;

}

};


main()
{

Item i1;
Product p1;
p1.setData(3,4);
i1=p1; // type casting from one class to another
i1.display();
return 0;




}







