#include<iostream>
using namespace std;

class Invent2
{

float x,y;

public:

Invent2()
{
}
void setx(int l)
{
x=l;
}
void sety(int m)
{
y=m;
}

void display()
{
cout<<"x= "<<x<<" y= "<<y<<endl;

}


};

class Invent1
{

float x,y;

public:

Invent1() // default constructor
{

}

Invent1(float l,float m)
{
x=l;
y=m;

}

operator float()
{
return x;

}

operator Invent2()
{
Invent2 temp;
temp.setx(x);
temp.sety(y);
return temp;

}
void display()
{
cout<<"x= "<<x<<" y= "<<y<<endl;

}



};
main()
{
Invent1 s1(4,5);
Invent2 d1;
float tv ;
tv=(float)s1;
cout<<tv<<endl;
d1=s1; // with the use of casting
d1.display();
return 0;

}














