#include<iostream>
using namespace std;

class Time
{
int x;
public:

Time()
{
}

Time(int y)
{
x=y;

}
void display()
{
cout<<"Time in minutes are "<<x<<endl;
}

};

main()
{

int duration;
cout<<"Enter time Duration in minutes ";
cin>>duration;
Time t1=duration;// parameterized constructor
t1.display();
return 0;

}
