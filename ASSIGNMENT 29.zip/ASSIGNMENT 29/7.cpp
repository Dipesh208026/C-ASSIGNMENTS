#include<iostream>
using namespace std;
class Minute
{

int m;

public:

Minute()
{

}

void setm(int y)

{
m=y;
}

void display()
{
cout<<" Minute is "<<m<<endl;
}

};

class Time
{
int hour ,minute;

public:

Time()
{
}
Time(int x,int y)
{
hour=x;
minute=y;
}

void display()
{
cout<<"hour is "<<hour<<" Minute is "<<minute<<endl;
}

operator Minute() // casting operator
{
Minute temp;
temp.setm(minute);
return temp;
}


};



main()
{
Time t1(2,30);
t1.display();
Minute m1;
m1.display();
m1=t1;  // Fetch minute from time // we would use typecasting operator
t1.display();
m1.display();
return 0;

}
