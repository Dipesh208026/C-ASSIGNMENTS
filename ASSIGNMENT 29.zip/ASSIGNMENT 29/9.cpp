#include<iostream>
using namespace std;

class Dollar
{
int d;
public:

Dollar()
{

}

Dollar(int x)
{
d=x;
}


void display()
{
cout<<"Dollar is "<<d<<endl;
}



};

main()
{
int x=50;
Dollar d; //default constructor
d=x;
d.display();
return 0;


}
