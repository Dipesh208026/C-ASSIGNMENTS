#include<iostream>
using namespace std;
class complex1{
private:

int real;
int imaginary;

public:
void display(complex1 c)
{
 cout<<real<<"+"<<imaginary<<"i"<<endl;
 cout<<c.real<<"+"<<c.imaginary<<"i"<<endl;

}
void  input()
{

    cout<<"Enter the real part: ";
    cin>>real;
cout<<"Enter the imaginary part: ";
cin>>imaginary;
}
void add(complex1 c)
{
    cout<<real+c.real<<"+"<<imaginary + c.imaginary<<"i";



}



};

main()
{

complex1 c1,c2;

c1.input();
c2.input();
c1.display(c2);
c1.add(c2);






}
