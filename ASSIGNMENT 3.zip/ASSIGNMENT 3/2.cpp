#include<iostream>
using namespace std;

class time
{
private:
int hour;
int minute;
int second;

public:
void display()
{
cout<<hour<<" hr "<<minute<<" min "<<second<<" sec ";

}

void input( )
{
cout<<"Enter the hours: ";
cin>>hour;
cout<<"Enter the minutes: ";
cin>>minute;
cout<<"Enter the seconds: ";
cin>>second;
}

};

main()
{
time c1;
c1.input();
c1.display();



}
