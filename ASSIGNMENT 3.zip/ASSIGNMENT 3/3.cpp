#include<iostream>
using namespace std;
class factorial
{
private:
int fact;
int result;

public:
void input()
{
cout<<"Enter the Number: ";
cin>>fact;
int i;
result=1;
for(i=fact;i>=1;i--)
{
result=result*i;

}

}

void display()
{

cout<<"Factorial of the number is: "<<result<<endl;


}
};

main()
{
factorial b;
b.input();
b.display();

}
