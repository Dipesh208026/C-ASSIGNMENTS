#include<iostream>
using namespace std;
class largest
{
private:
int a;
int b;
int c;
int max1;

public :
input()
{
cout<<"Enter the first number: ";
cin>>a;
cout<<"Enter the second number: ";
cin>>b;
cout<<"Enter the third number: ";
cin>>c;

 max1;
max1=a>b&&a>c?a:(b>c&&b>a?b:c);

}

display()
{

cout<<"Maximum of three number is: "<<max1<<endl;



}




};


main()
{

largest b1;
b1.input();
b1.display();


}

