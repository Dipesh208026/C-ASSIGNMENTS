#include<iostream>
using namespace std;
class reverse {

private:
int a;
int j;
int b[100];

public:

void input()
{
cout<<"Enter the number You want to reverse: ";
cin>>a;
int i=0;
while(a!=0)
{
int r,q;
r=a%10;
q=a/10;
a=q;
b[i]=r;
i++;
j=i;
}


}

void display()
{
int i;
for(i=0;i<=j-1;i++)
{
cout<<b[i];
}
}
};

main()
{

reverse b1;
b1.input();
b1.display();

}
