#include<iostream>
using namespace std;
class square{

private:
int result;

public:

void input()
{
int a;
cout<<"Enter the number: ";
cin>>a;
result=a*a;


}

void display()
{
cout<<"Sqaure of a number is: "<<result<<endl;

}

};

main()
{

square b1;
b1.input();
b1.display();
}
