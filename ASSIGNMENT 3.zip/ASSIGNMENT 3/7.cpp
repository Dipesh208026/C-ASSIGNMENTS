#include<iostream>
using namespace std;
class rectangle{

private:
int result;

public:

void input()
{
int a,b;
cout<<"Enter the length of rectangle: ";
cin>>a;
cout<<"Enter the breadth of rectangle: ";
cin>>b;
result=a*b;


}

void display()
{
cout<<"Area of rectangle is: "<<result<<endl;

}

};

main()
{

rectangle b1;
b1.input();
b1.display();
}
