#include<iostream>
using namespace std;
class circle{

private:
float result;

public:

void input()
{
int a,b;
cout<<"Enter the radius of circle: ";
cin>>a;
result=(float)3.14*a;


}

void display()
{
cout<<"Area of Circle is: "<<result<<endl;

}

};

main()
{

circle b1;
b1.input();
b1.display();
}
