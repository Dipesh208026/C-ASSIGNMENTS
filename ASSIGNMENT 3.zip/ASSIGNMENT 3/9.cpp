#include<iostream>
using namespace std;
class area{

private:
int result_rectangle;
float result_circle;
int result_square;
int r;

public:
void input()
{
cout<<"Enter the choice you want: "<<"\n";
cout<<"1. Area of Rectangle: "<<endl;
cout<<"2. Area of Circle: "<<endl;
cout<<"3. Area of Square: "<<endl;

cin>>r;
switch(r)
{
case 1:
rectangle();
break;
case 2:
circle();
break;
case 3:
square();
break;
default:
cout<<"Please Enter Correct choice ";

}

}

void rectangle()
{
int a,b;
cout<<"Enter the length of rectangle: ";
cin>>a;
cout<<"Enter the breadth of rectangle: ";
cin>>b;
result_rectangle=a*b;

}
void square()
{
int d;
cout<<"Enter the side of a Square: ";
cin>>d;
result_square=d*d;

}

void circle()
{
int e;
cout<<"Enter the radius of circle: ";
cin>>e;
result_circle=(float)3.14*e;

}

void display()
{
    if(r==1)
   cout<<"Area of Rectangle is: "<<result_rectangle<<endl;
   else if(r==2)
    cout<<"Area of Circle is: "<<result_circle<<endl;
   else if(r==3)
    cout<<"Area of Square is: "<<result_square<<endl;


}
};

main()
{

area b1;
b1.input();
b1.display();
}
